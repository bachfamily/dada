function [X, Y] = dg_convhull(X_in, Y_in)
K = convhull(X_in, Y_in);
X = X_in(K(end:-1:1));
Y = Y_in(K(end:-1:1));