function [X_out, Y_out] = dg_extrude_smart(X_poly, Y_poly, amount)
n = size(X_poly, 2);

[Xc, Yc] = dg_centroid(X_poly, Y_poly);

%hold on
%plot(Xc, Yc, 'k.')
C = [Xc Yc];

%standard extrusion:
for i = 1:n
    P = [X_poly(i) Y_poly(i)];
    Pextr = P - amount * (C - P)/norm(C - P);
    X_out(i) = Pextr(1);
    Y_out(i) = Pextr(2);
end

