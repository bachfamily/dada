 X_blue = [7.0605    0.3183    2.7692    0.4617    0.9713    8.2346    6.9483    3.1710    9.5022    0.3445 4 3.8 4 7];
 Y_blue = [4.3874    3.8156    7.6552    7.9520    1.8687    4.8976    4.4559    6.4631    7.0936    7.5469 4 4 3.7 0.5];
 X_red = [ 4.1889    2.5545    2.5972    3.0300    5.3629    3.0171 8];
 Y_red = [ 5.2571    2.9741    5.7171    3.3999    2.7864    3.0043 0.2];
 
 N_blue = 10;
 N_red = 5;
% X_blue = random('Uniform', 0, 10, 1, N_blue);
% Y_blue = random('Uniform', 0, 10, 1, N_blue);
% X_red = random('Uniform', 0, 10, 1, N_red);
% Y_red = random('Uniform', 0, 10, 1, N_red);

clf;
plot(X_blue, Y_blue, 'b.');
hold on;
plot(X_red, Y_red, 'r.');

extrude_amount = 1;

% compute convex hull of blue stuff
[X, Y] = dg_convhull(X_blue, Y_blue);
[X, Y] = dg_extrude_smart(X, Y, extrude_amount);


while 1
    
    %%%%%% STEP 1: DELETE RED ELEMENTS
    this_extrude_amount = extrude_amount;
    while 1
        % compute how many red points are left inside the convex hull
        I = inpolygon(X_red,Y_red,X,Y)
        
        if sum(I) == 0
            return % no more red points in the polygon, we're done
        end
        
        X_remove = X_red(I == 1);
        Y_remove = Y_red(I == 1);
        
        % compute convex hull of red stuff
        [Xh, Yh] = dg_convhull(X_remove, Y_remove);
        [Xh, Yh] = dg_extrude_smart(Xh, Yh, this_extrude_amount);

        % Careful: if the red convex hull is BIGGER than the blue one, we join
        % them
        [Xnew, Ynew] = polybool('union', X, Y, Xh, Yh);
        
        if (isequal(Xnew, X) && isequal(Ynew, Y))
            break;
        end
        X = Xnew;
        Y = Ynew;
        % and we set the red one with a smaller extrusion threshold
        this_extrude_amount = this_extrude_amount * 0.5;
    end
   
    plot(X, Y, 'b-', 'LineWidth',1);
    hold on;
    
    % NOW WE NEED TO REMOVE Xh Yh from X Y
    [X, Y] = dg_combine_poly(X, Y, Xh, Yh, 0, X_blue, Y_blue, X_red, Y_red);
    
    
    %%%%%% STEP 2: RE-INSERT BLUE ELEMENTS
    % compute how many blue points are left OUTSIDE the convex hull
    I = 1 - inpolygon(X_blue,Y_blue,X,Y);
    
    if sum(I) == 0
        return % no more blue points in the polygon, we're done
    end
    
    X_add = X_blue(I == 1);
    Y_add = Y_blue(I == 1);
    
    % compute convex hull of blue stuff
    [Xh, Yh] = dg_convhull(X_add, Y_add);
    [Xh, Yh] = dg_extrude_smart(Xh, Yh, extrude_amount);
    
    Xh
    Yh
    
    [X, Y] = dg_combine_poly(X, Y, Xh, Yh, 1, X_blue, Y_blue, X_red, Y_red);

    
    break
end