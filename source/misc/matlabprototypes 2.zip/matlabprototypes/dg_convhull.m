function [X, Y] = dg_convhull(X_in, Y_in)
epsilon = 0.1;
L = length(X_in);
if (L == 1)
    X = [X_in-epsilon X_in-epsilon X_in+epsilon X_in+epsilon];
    Y = [Y_in-epsilon Y_in+epsilon Y_in+epsilon Y_in-epsilon];
elseif (L == 2)
    minx = min(X_in);
    maxx = max(X_in);
    miny = min(Y_in);
    maxy = max(Y_in);
    X = [minx-epsilon maxx-epsilon maxx+epsilon minx+epsilon];
    Y = [miny-epsilon miny+epsilon miny+epsilon miny-epsilon];
else
    K = convhull(X_in, Y_in);
    X = X_in(K(end:-1:1));
    Y = Y_in(K(end:-1:1));
end