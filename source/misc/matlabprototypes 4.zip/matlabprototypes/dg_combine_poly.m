function [Xout, Yout] = dg_combine_poly(X, Y, Xh, Yh, type, X_blue, Y_blue, X_red, Y_red)
    plot_verbose = 0;

    % calculating side half points
    L = length(Xh) - 1;
    [Xc, Yc] = dg_centroid(Xh, Yh);
    Xhm = 0.5 * (Xh(1:L) + [Xh(2:L) Xh(1)]);
    Yhm = 0.5 * (Yh(1:L) + [Yh(2:L) Yh(1)]);

    if (plot_verbose)
        if (type == 0) % remove
            plot(Xh, Yh, 'r-');
            hold on;
        else % add
            plot(Xh, Yh, 'b-');
            hold on;
        end
    end
    
    
    % ...and extending the vector they create with the Xc, Yc so that it
    % surely intersects the X Y polygon
    d = dg_upperbounddiameter(X, Y);
    Xhm2 = Xhm;
    Yhm2 = Yhm;
    Xi = zeros(1,L);
    Yi = zeros(1,L);
    Ii = zeros(1,L);
    for i = 1:L
        rad = ([Xhm(i) Yhm(i)] - [Xc Yc]);
        P = [Xhm(i) Yhm(i)] + rad * d / norm(rad);
        Xhm2(i) = P(1);
        Yhm2(i) = P(2);

        if (type == 1)
            plot([Xc Xhm2(i)], [Yc Yhm2(i)], 'k.-')
        end
        [thisx,thisy,thisidx] = POLYXPOLY([Xc Xhm2(i)], [Yc Yhm2(i)], X, Y);

        % among the thisx, we must choose the one NEAREST TO Xc Yc
        if (isempty(thisx))
            Xi(i) = 0;
            Yi(i) = 0;
            Ii(i) = 0;
        else 
            %we choose the 
            thisx
            thisy
            P = [thisx' ; thisy']'
            mindist = -1;
            chosenidx  = 1;
            for j = 1:length(thisx)
                [Xc Yc]
                thisdist = pdist([Xc Yc; P(j,:)], 'euclidean')
                if (thisdist < mindist || mindist < 0)
                    chosenidx = j;
                    mindist = thisdist;
                end
            end
            P
            thisx
            thisy
            thisidx
            chosenidx
            
            Xi(i) = thisx(chosenidx);
            Yi(i) = thisy(chosenidx);
            Ii(i) = thisidx(chosenidx, 2);

            if (type == 1)
                plot([thisx(chosenidx)], [thisy(chosenidx)], 'k*-')
            end
        end
    end
    
    % for each intersection point, build corresponding "hole" quadrilater
    Xq = [];
    Yq = [];
    Nhq = []; % number of blue points inside the quadrilater
    Dq = []; % distance from halfside to corresponding halfside
    Xmiddle1 = [];
    Ymiddle1 = [];
    Xmiddle2 = [];
    Ymiddle2 = [];
    Good = [];
    for i = 1:L
        i
        if (Ii(i) == 0) % no good!
            Good = [Good 0];
            Xq = [Xq 0];
            Yq = [Yq 0];
            Nhq = [Nhq 0]; % and count num blue points inside it
            Dq = [Dq 0];
            Xmiddle1 = [Xmiddle1 0];
            Ymiddle1 = [Ymiddle1 0];
            Xmiddle2 = [Xmiddle2 0];
            Ymiddle2 = [Ymiddle2 0];
        else
            perc = 0.333;

            
            while (perc > 0.01)
                regular = 0;
                notpassingoveritself= 0;
                
                thisxmiddle1 = (1-perc)*X(Ii(i)+1) + perc*X(Ii(i));
                thisxmiddle2 = perc*X(Ii(i)+1) + (1-perc)*X(Ii(i));
                thisymiddle1 = (1-perc)*Y(Ii(i)+1) + perc*Y(Ii(i));
                thisymiddle2 = perc*Y(Ii(i)+1) + (1-perc)*Y(Ii(i));
                
                % check if quadrilater will be regular
                res = polyxpoly([thisxmiddle2 Xh(i)], [thisymiddle2 Yh(i)], [Xh(i+1) thisxmiddle1], [Yh(i+1) thisymiddle1]);
                if (type == 1)
%                    plot([thisxmiddle2 Xh(i)], [thisymiddle2 Yh(i)], 'r*-', 'LineWidth', 2');
 %                   plot([Xh(i+1) thisxmiddle1], [Yh(i+1) thisymiddle1], 'b*-', 'LineWidth', 2');
                    res
                end
                
                if (isempty(res))
                    regular = 1;
                end
                
                X_quad = [Xh(i) Xh(i+1) thisxmiddle1 thisxmiddle2  Xh(i)];
                Y_quad = [Yh(i) Yh(i+1) thisymiddle1 thisymiddle2 Yh(i)];
                [Xm, Ym] = polybool('intersection', Xh, Yh, X_quad, Y_quad);
                if (type == 1)
                    plot(Xh, Yh, 'g*-', 'LineWidth', 2');
                    plot(X_quad, Y_quad, 'y*-', 'LineWidth', 2');
                    Xm
                    Ym
                end
                notpassingoveritself  = 1;
                
                if (regular && notpassingoveritself)
                    break;
                end
                perc = perc / 2;
            end
            
            X_quad = [Xh(i) Xh(i+1) thisxmiddle1 thisxmiddle2  Xh(i)];
            Y_quad = [Yh(i) Yh(i+1) thisymiddle1 thisymiddle2 Yh(i)];

            %        plot(X_quad, Y_quad, 'k-')
            if (type == 0)
                hits = inpolygon(X_blue,Y_blue,X_quad,Y_quad);
            else
                hits = inpolygon(X_red,Y_red,X_quad,Y_quad);
            end
            Xq = [Xq [X_quad]];
            Yq = [Yq [Y_quad]];
            Nhq = [Nhq sum(hits)]; % and count num blue points inside it
            Dq = [Dq pdist2([Xhm(i) Yhm(i)], [Xi(i) Yi(i)])];
            Xmiddle1 = [Xmiddle1 thisxmiddle1];
            Ymiddle1 = [Ymiddle1 thisymiddle1];
            Xmiddle2 = [Xmiddle2 thisxmiddle2];
            Ymiddle2 = [Ymiddle2 thisymiddle2];
            Good = [Good 1];
        end
    end
    
    L
    Nhq
    Dq
    Good
    
    nh = min(Nhq);
    
    % If all quadrilaters have blue/red points, we need to refine stuff (OR
    % NOT???)
    if nh > 0
        % TO DO
    end
    
    % We choose the "best" quadrilater
    Dq(Nhq~=0) = Dq(Nhq~=0) + max(Dq) + 1;
    Dq(Good==0) = Dq(Good==0) + max(Dq) + 1;
    [chd q] = min(Dq); % q contains the index
    if (~Good(q))
        q = randi([1 L]); % Bad case....
    end
    
    if (type == 0)
        % We "remove" the chosen quadrilater from the original X Y polygon
        X = [X(1:Ii(q))  Xmiddle2(q)  Xh(q:-1:1) Xh(L:-1:q+1)  Xmiddle1(q)  X(Ii(q)+1:length(X))];
        Y = [Y(1:Ii(q))  Ymiddle2(q)  Yh(q:-1:1) Yh(L:-1:q+1)  Ymiddle1(q)  Y(Ii(q)+1:length(Y))];
        X_pt = X_blue;
        Y_pt = Y_blue;
    else
        % We "add" the chosen quadrilater to the original X Y polygon
        X = [X(1:Ii(q))  Xmiddle2(q)  Xh(q+1:L) Xh(1:q) Xmiddle1(q)  X(Ii(q)+1:length(X))];
        Y = [Y(1:Ii(q))  Ymiddle2(q)  Yh(q+1:L) Yh(1:q) Ymiddle1(q)  Y(Ii(q)+1:length(Y))];
        X_pt = X_red;
        Y_pt = Y_red;
    end
    
    if (1 == 1) % prune?
        il = Ii(q);
        ir = Ii(q) + L + 1;
        % pruning created points if possible
        if (sum(inpolygon(X_pt,Y_pt,[X(il) X(il+1) X(il+2)], [Y(il) Y(il+1) Y(il+2)])) == 0)
            X = [X(1:il) X(il+2:end)];
            Y = [Y(1:il) Y(il+2:end)];
            ir = ir - 1;
        end
        
        if (sum(inpolygon(X_pt,Y_pt,[X(ir) X(ir+1) X(ir+2)], [Y(ir) Y(ir+1) Y(ir+2)])) == 0)
            X = [X(1:ir) X(ir+2:end)];
            Y = [Y(1:ir) Y(ir+2:end)];
        end
    end

    
    if (plot_verbose)
        if (type == 0)
            plot(X, Y, 'b:','LineWidth',2);
        else
            plot(X, Y, 'k:','LineWidth',2);
        end
        hold on;
    end
    
    Xout = X;
    Yout = Y;
    