function [Xout, Yout] = dg_combine_poly(X, Y, Xh, Yh, type, X_blue, Y_blue, X_red, Y_red)


    % calculating side half points
    L = length(Xh) - 1;
    [Xc, Yc] = dg_centroid(Xh, Yh);
    Xhm = 0.5 * (Xh(1:L) + [Xh(2:L) Xh(1)]);
    Yhm = 0.5 * (Yh(1:L) + [Yh(2:L) Yh(1)]);

    if (type == 0)
        plot(Xh, Yh, 'r-');
        hold on;
    else
        plot(Xh, Yh, 'y-');
        hold on;
    end
    
    
    % ...and extending the vector they create with the Xc, Yc so that it
    % surely intersects the X Y polygon
    d = dg_upperbounddiameter(X, Y);
    Xhm2 = Xhm;
    Yhm2 = Yhm;
    Xi = zeros(1,L);
    Yi = zeros(1,L);
    Ii = zeros(1,L);
    for i = 1:L
        rad = ([Xhm(i) Yhm(i)] - [Xc Yc]);
        P = [Xhm(i) Yhm(i)] + rad * d / norm(rad);
        Xhm2(i) = P(1);
        Yhm2(i) = P(2);

        [thisx,thisy,thisidx] = POLYXPOLY([Xc Xhm2(i)], [Yc Yhm2(i)], X, Y);

        % among the thisx, we must choose the one NEAREST TO Xc Yc
        thisx
        Xi(i) = thisx(1);
        Yi(i) = thisy(1);
        Ii(i) = thisidx(2);
    end
    
    % for each intersection point, build corresponding "hole" quadrilater
    Xq = [];
    Yq = [];
    Nhq = []; % number of blue points inside the quadrilater
    Dq = []; % distance from halfside to corresponding halfside
    Xmiddle1 = [];
    Ymiddle1 = [];
    Xmiddle2 = [];
    Ymiddle2 = [];
    for i = 1:L
        thisxmiddle1 = (2*X(Ii(i)+1)+X(Ii(i)))/3.;
        thisxmiddle2 = (X(Ii(i)+1)+2*X(Ii(i)))/3.;
        thisymiddle1 = (2*Y(Ii(i)+1)+Y(Ii(i)))/3.;
        thisymiddle2 = (Y(Ii(i)+1)+2*Y(Ii(i)))/3.;
        X_quad = [Xh(i) Xh(i+1) thisxmiddle1 thisxmiddle2  Xh(i)];
        Y_quad = [Yh(i) Yh(i+1) thisymiddle1 thisymiddle2 Yh(i)];
        %        plot(X_quad, Y_quad, 'k-')
        if (type == 0)
            hits = inpolygon(X_blue,Y_blue,X_quad,Y_quad);
        else
            hits = inpolygon(X_red,Y_red,X_quad,Y_quad);
        end
        Xq = [Xq [X_quad]];
        Yq = [Yq [Y_quad]];
        Nhq = [Nhq sum(hits)]; % and count num blue points inside it
        Dq = [Dq pdist2([Xhm(i) Yhm(i)], [Xi(i) Yi(i)])];
        Xmiddle1 = [Xmiddle1 thisxmiddle1];
        Ymiddle1 = [Ymiddle1 thisymiddle1];
        Xmiddle2 = [Xmiddle2 thisxmiddle2];
        Ymiddle2 = [Ymiddle2 thisymiddle2];
    end
    
    plot(Xi, Yi, 'go');
    hold on;

    L
    Nhq
    Dq
    
    nh = min(Nhq);
    
    % If all quadrilaters have blue/red points, we need to refine stuff (OR
    % NOT???)
    if nh > 0
        % TO DO
    end
    
    % We choose the "best" quadrilater
    Dq(Nhq~=0) = Dq(Nhq~=0) + max(Dq) + 1;
    [chd q] = min(Dq); % q contains the index
    
    if (type == 0)
        % We "remove" the chosen quadrilater from the original X Y polygon
        X = [X(1:Ii(q))  Xmiddle2(q)  Xh(q:-1:1) Xh(L:-1:q+1)  Xmiddle1(q)  X(Ii(q)+1:length(X))];
        Y = [Y(1:Ii(q))  Ymiddle2(q)  Yh(q:-1:1) Yh(L:-1:q+1)  Ymiddle1(q)  Y(Ii(q)+1:length(Y))];
        
         il = Ii(q)
         ir = Ii(q) + L + 1
         plot(X(2), Y(2), 'ko');
         % pruning created points if possible
         if (sum(inpolygon(X_blue,Y_blue,[X(il) X(il+1) X(il+2)], [Y(il) Y(il+1) Y(il+2)])) == 0)
             X = [X(1:il) X(il+2:end)];
             Y = [Y(1:il) Y(il+2:end)];
             ir = ir - 1;
         end
         
         if (sum(inpolygon(X_blue,Y_blue,[X(ir) X(ir+1) X(ir+2)], [Y(ir) Y(ir+1) Y(ir+2)])) == 0)
             X = [X(1:ir) X(ir+2:end)];
             Y = [Y(1:ir) Y(ir+2:end)];
         end
    else
        % We "add" the chosen quadrilater to the original X Y polygon
        X = [X(1:Ii(q))  Xmiddle2(q)  Xh(q:-1:1) Xh(L:-1:q+1)  Xmiddle1(q)  X(Ii(q)+1:length(X))];
        Y = [Y(1:Ii(q))  Ymiddle2(q)  Yh(q:-1:1) Yh(L:-1:q+1)  Ymiddle1(q)  Y(Ii(q)+1:length(Y))];
    end
    
    if (type == 0)
        plot(X, Y, 'b:','LineWidth',2);
    else
        plot(X, Y, 'k:','LineWidth',2);
    end
    hold on;
    
    Xout = X;
    Yout = Y;
    