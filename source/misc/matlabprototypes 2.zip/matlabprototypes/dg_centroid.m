function [Xc, Yc] = dg_centroid(X, Y)
Xc = mean(X);
Yc = mean(Y);