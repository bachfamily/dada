 X_blue = [7.0605    0.3183    2.7692    0.4617    0.9713    8.2346    6.9483    3.1710    9.5022    0.3445 4 3.8 4 7];
 Y_blue = [4.3874    3.8156    7.6552    7.9520    1.8687    4.8976    4.4559    6.4631    7.0936    7.5469 4 4 3.7 0.5];
 X_red = [ 4.1889    2.5545    2.5972    3.0300    5.3629    3.0171 8];
 Y_red = [ 5.2571    2.9741    5.7171    3.3999    2.7864    3.0043 0.2];
 
 N_blue = 20;
 N_red = 10;
 X_blue = random('Uniform', 0, 10, 1, N_blue);
 Y_blue = random('Uniform', 0, 10, 1, N_blue);
 X_red = random('Uniform', 0, 10, 1, N_red);
 Y_red = random('Uniform', 0, 10, 1, N_red);

clf;
plot(X_blue, Y_blue, 'b.');
hold on;
plot(X_red, Y_red, 'r.');

extrude_amount = 1;

% compute convex hull of blue stuff
[X, Y] = dg_convhull(X_blue, Y_blue);
[X, Y] = dg_extrude_smart(X, Y, extrude_amount);


while 1
    
    %%%%%% STEP 1: DELETE RED ELEMENTS
    this_extrude_amount = extrude_amount;
    while 1
        % compute how many red points are left inside the convex hull
        I = inpolygon(X_red,Y_red,X,Y)
        
        if sum(I) == 0
            break % no more red points in the polygon, we're done
        end
        
        X_remove = X_red(I == 1);
        Y_remove = Y_red(I == 1);
        
        % compute convex hull of red stuff
        [Xh, Yh] = dg_convhull(X_remove, Y_remove);
        [Xh, Yh] = dg_extrude_smart(Xh, Yh, this_extrude_amount);

        % Careful: if the red convex hull is BIGGER than the blue one, we join
        % them
        [Xnew, Ynew] = polybool('union', X, Y, Xh, Yh);
        
        if (isequal(Xnew, X) && isequal(Ynew, Y))
            break;
        end
        X = Xnew;
        Y = Ynew;
        % and we set the red one with a smaller extrusion threshold
        this_extrude_amount = this_extrude_amount * 0.5;
    end
    
    plot(X, Y, 'b-', 'LineWidth',1);
    hold on;
    plot(Xh, Yh, 'r-');
    hold on;
    
    
    % calculating side half points
    L = length(Xh) - 1;
    [Xc, Yc] = dg_centroid(X_remove, Y_remove);
    Xhm = 0.5 * (Xh(1:L) + [Xh(2:L) Xh(1)]);
    Yhm = 0.5 * (Yh(1:L) + [Yh(2:L) Yh(1)]);
    plot(Xc, Yc, 'rx');
    hold on;
    % ...and extending the vector they create with the Xc, Yc so that it
    % surely intersects the X Y polygon
    d = dg_upperbounddiameter(X, Y);
    Xhm2 = Xhm;
    Yhm2 = Yhm;
    Xi = zeros(1,L);
    Yi = zeros(1,L);
    Ii = zeros(1,L);
    for i = 1:L
        rad = ([Xhm(i) Yhm(i)] - [Xc Yc]);
        P = [Xhm(i) Yhm(i)] + rad * d / norm(rad);
        Xhm2(i) = P(1);
        Yhm2(i) = P(2);

        [thisx,thisy,thisidx] = POLYXPOLY([Xc Xhm2(i)], [Yc Yhm2(i)], X, Y);
        Xi(i) = thisx;
        Yi(i) = thisy;
        Ii(i) = thisidx(2);
    end
    
    % for each intersection point, build corresponding "hole" quadrilater
    Xq = [];
    Yq = [];
    Nhq = []; % number of blue points inside the quadrilater
    Dq = []; % distance from halfside to corresponding halfside
    Xmiddle1 = [];
    Ymiddle1 = [];
    Xmiddle2 = [];
    Ymiddle2 = [];
    for i = 1:L
        thisxmiddle1 = (2*X(Ii(i)+1)+X(Ii(i)))/3.;
        thisxmiddle2 = (X(Ii(i)+1)+2*X(Ii(i)))/3.;
        thisymiddle1 = (2*Y(Ii(i)+1)+Y(Ii(i)))/3.;
        thisymiddle2 = (Y(Ii(i)+1)+2*Y(Ii(i)))/3.;
        X_quad = [Xh(i) Xh(i+1) thisxmiddle1 thisxmiddle2  Xh(i)];
        Y_quad = [Yh(i) Yh(i+1) thisymiddle1 thisymiddle2 Yh(i)];
%        plot(X_quad, Y_quad, 'k-')
        hits = inpolygon(X_blue,Y_blue,X_quad,Y_quad);
        Xq = [Xq [X_quad]];
        Yq = [Yq [Y_quad]];
        Nhq = [Nhq sum(hits)]; % and count num blue points inside it
        Dq = [Dq pdist2([Xhm(i) Yhm(i)], [Xi(i) Yi(i)])];
        Xmiddle1 = [Xmiddle1 thisxmiddle1];
        Ymiddle1 = [Ymiddle1 thisymiddle1];
        Xmiddle2 = [Xmiddle2 thisxmiddle2];
        Ymiddle2 = [Ymiddle2 thisymiddle2];
    end
    
    plot(Xhm, Yhm, 'rx');
    hold on;
    plot(Xi, Yi, 'go');
    hold on;

    L
    Nhq
    Dq
    
    nh = min(Nhq);
    
    % If all quadrilaters have blue points, we need to refine stuff
    if nh > 0
        % TO DO
    end
    
    % We choose the proper quadrilater
    Dq(Nhq~=0) = Dq(Nhq~=0) + max(Dq) + 1;
    [chd q] = min(Dq); % q contains the index
    
    % We "remove" the chosen quadrilater from the original X Y polygon
    X = [X(1:Ii(q))  Xmiddle2(q)  Xh(q:-1:1) Xh(L:-1:q+1)  Xmiddle1(q)  X(Ii(q)+1:length(X))];
    Y = [Y(1:Ii(q))  Ymiddle2(q)  Yh(q:-1:1) Yh(L:-1:q+1)  Ymiddle1(q)  Y(Ii(q)+1:length(Y))];

    il = Ii(q);
    ir = Ii(q) + L;
    % pruning created points if possible
    if (sum(inpolygon(X_blue,Y_blue,[X(il) X(il+1) X(il+2)], [Y(il) Y(il+1) Y(il+2)])) == 0)
        X = [X(1:il) X(il+2:end)];
        Y = [Y(1:il) Y(il+2:end)];
        ir = ir - 1;
    end

    if (sum(inpolygon(X_blue,Y_blue,[X(ir) X(ir+1) X(ir+2)], [Y(ir) Y(ir+1) Y(ir+2)])) == 0)
        X = [X(1:ir) X(ir+2:end)];
        Y = [Y(1:ir) Y(ir+2:end)];
    end
    
    plot(X, Y, 'b:','LineWidth',2);
    hold on;
    
    
    
    
    
    
    %%%%%% STEP 2: RE-INSERT BLUE ELEMENTS

    break
end