function [X_out, Y_out] = dg_extrude_smart(X_poly, Y_poly, amount, X_unwanted, Y_unwanted, type, X_set, Y_set)
n = size(X_poly, 2);
amount_used = amount;

if (type == 2)
    [X_intA, Y_intA] = polybool('intersection', X_poly, Y_poly, X_set, Y_set);
else
    X_intA = [0];
end

while 1
    
    X_out = X_poly;
    Y_out = Y_poly;
    [Xc, Yc] = dg_centroid(X_poly, Y_poly);
    
    C = [Xc Yc];
    
    I_before = inpolygon(X_unwanted,Y_unwanted,X_poly,Y_poly);
    
    %standard extrusion:
    for i = 1:n
        P = [X_poly(i) Y_poly(i)];
        Pextr = P - amount_used * (C - P)/norm(C - P);
        X_out(i) = Pextr(1);
        Y_out(i) = Pextr(2);
    end
    
    I_after= inpolygon(X_unwanted,Y_unwanted,X_out,Y_out);
    
    if (type == 1)
        [X_int, Y_int] = polybool('subtraction', X_out, Y_out, X_set, Y_set);
    elseif (type == 2)
        [X_int, Y_int] = polybool('intersection', X_out, Y_out, X_set, Y_set);
    else 
        X_int = [];
    end
        
    X_int
    
    if (isequal(I_before, I_after) && (isempty(X_int) || (~isempty(X_intA))))
        return;
    end
    
    amount_used = amount_used * 0.5;
end

        
