Contents of polygeom.zip - 08.11.30

polygeom.m - MATLAB code to compute area, centroid 
  perimeter and moments of inertia for a polygonal outline

test_polygeom.m - MATLAB code to test polygeom

polygeom.doc - MS-Word table with analytical summations
  used for computations, also describes how to handle holes

3x5_rectangle.jpg - JPG from test_polygeom

***********************************************************
H.J. Sommer III, Ph.D., Professor of Mechanical Engineering
The Pennsylvania State University
337 Leonhard Building, University Park, PA 16802
(814)863-8997   FAX (814)865-9693
hjs1@psu.edu    http://www.mne.psu.edu/sommer/