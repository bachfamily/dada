function [Xout, Yout] = dg_combine_poly(X, Y, Xh, Yh, type)


